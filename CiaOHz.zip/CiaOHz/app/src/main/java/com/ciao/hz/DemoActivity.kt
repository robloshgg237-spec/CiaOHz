package com.ciao.hz

import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import kotlin.math.abs

/**
 * Halaman contoh: geser kanan-kiri. Jika "Motion Blur" aktif, halaman yang
 * sedang bergerak diberi blur sesuai jarak geseran.
 */
class DemoActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = getString(R.string.demo_title)

        val blurOn = PreferenceManager.getDefaultSharedPreferences(this)
            .getBoolean("motion_blur", false)

        val pager = ViewPager2(this).apply {
            adapter = PageAdapter()
            setPageTransformer { page, position ->
                val p = abs(position).coerceIn(0f, 1f)
                if (blurOn && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val r = p * 30f
                    page.setRenderEffect(
                        if (r < 0.5f) null
                        else RenderEffect.createBlurEffect(r, 0.01f, Shader.TileMode.CLAMP)
                    )
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    page.setRenderEffect(null)
                }
            }
        }
        setContentView(pager)
    }

    override fun finish() {
        super.finish()
        overridePendingTransition(R.anim.close_enter, R.anim.close_exit)
    }

    private class PageAdapter : RecyclerView.Adapter<PageAdapter.VH>() {
        private val colors = intArrayOf(
            Color.parseColor("#E5E2DC"),
            Color.parseColor("#6C5CE7"),
            Color.parseColor("#2B2A26")
        )

        class VH(val root: FrameLayout) : RecyclerView.ViewHolder(root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
            val frame = FrameLayout(parent.context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            frame.addView(TextView(parent.context).apply {
                textSize = 48f
                gravity = Gravity.CENTER
                tag = "label"
            }, FrameLayout.LayoutParams(-1, -1))
            return VH(frame)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val bg = colors[position % colors.size]
            holder.root.setBackgroundColor(bg)
            val label = holder.root.findViewWithTag<TextView>("label")
            label.text = "CiaO ${position + 1}"
            val light = position % colors.size == 0
            label.setTextColor(if (light) Color.parseColor("#2B2A26") else Color.WHITE)
        }

        override fun getItemCount() = colors.size
    }
}
