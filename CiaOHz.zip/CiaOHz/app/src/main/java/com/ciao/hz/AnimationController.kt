package com.ciao.hz

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

/**
 * Mengatur skala animasi sistem dan refresh rate.
 *
 * - Skala animasi (window/transition/animator) ada di Settings.Global dan butuh
 *   WRITE_SECURE_SETTINGS (diberikan sekali lewat ADB).
 * - Refresh rate (min/peak_refresh_rate) ada di Settings.System dan butuh
 *   izin WRITE_SETTINGS (diberikan pengguna di layar sistem). Hanya berfungsi
 *   di HP yang membaca key tersebut (banyak Pixel/Samsung/Xiaomi/Realme dsb.).
 */
object AnimationController {

    private const val PREFS = "ciao_hz_state"
    private const val SMOOTH_SCALE = 0.5f
    private const val TARGET_HZ = 240f

    private val globalKeys = listOf(
        Settings.Global.WINDOW_ANIMATION_SCALE,
        Settings.Global.TRANSITION_ANIMATION_SCALE,
        Settings.Global.ANIMATOR_DURATION_SCALE
    )
    private val refreshKeys = listOf("min_refresh_rate", "peak_refresh_rate")

    fun hasSecurePermission(ctx: Context): Boolean =
        ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) ==
            PackageManager.PERMISSION_GRANTED

    fun canWriteSystem(ctx: Context): Boolean = Settings.System.canWrite(ctx)

    /** @return true jika bagian animasi berhasil diterapkan. */
    fun setSmoother(ctx: Context, enabled: Boolean): Boolean {
        val prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val cr = ctx.contentResolver
        var animOk = false

        if (hasSecurePermission(ctx)) {
            try {
                if (enabled) {
                    // simpan nilai asli sekali saja
                    if (!prefs.getBoolean("saved_global", false)) {
                        val e = prefs.edit()
                        globalKeys.forEach {
                            e.putFloat(it, Settings.Global.getFloat(cr, it, 1f))
                        }
                        e.putBoolean("saved_global", true).apply()
                    }
                    globalKeys.forEach { Settings.Global.putFloat(cr, it, SMOOTH_SCALE) }
                } else {
                    globalKeys.forEach {
                        Settings.Global.putFloat(cr, it, prefs.getFloat(it, 1f))
                    }
                    prefs.edit().putBoolean("saved_global", false).apply()
                }
                animOk = true
            } catch (_: SecurityException) {
            }
        }

        if (canWriteSystem(ctx)) {
            try {
                if (enabled) {
                    if (!prefs.getBoolean("saved_refresh", false)) {
                        val e = prefs.edit()
                        refreshKeys.forEach {
                            e.putFloat(it, Settings.System.getFloat(cr, it, 0f))
                        }
                        e.putBoolean("saved_refresh", true).apply()
                    }
                    refreshKeys.forEach { Settings.System.putFloat(cr, it, TARGET_HZ) }
                } else {
                    refreshKeys.forEach {
                        Settings.System.putFloat(cr, it, prefs.getFloat(it, 0f))
                    }
                    prefs.edit().putBoolean("saved_refresh", false).apply()
                }
            } catch (_: SecurityException) {
            }
        }
        return animOk
    }
}
