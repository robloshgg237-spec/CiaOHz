package com.ciao.hz

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import androidx.preference.SwitchPreferenceCompat

class SettingsFragment : PreferenceFragmentCompat() {

    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.preferences, rootKey)

        findPreference<SwitchPreferenceCompat>("max_animation_smoother")
            ?.setOnPreferenceChangeListener { _, newValue ->
                val enabled = newValue as Boolean
                val ctx = requireContext()

                // refresh rate: butuh izin WRITE_SETTINGS dari pengguna
                if (enabled && !AnimationController.canWriteSystem(ctx)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_WRITE_SETTINGS,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                }

                val ok = AnimationController.setSmoother(ctx, enabled)
                if (!ok) {
                    Toast.makeText(
                        ctx,
                        "Izin ADB belum diberikan. Lihat README (langkah 3).",
                        Toast.LENGTH_LONG
                    ).show()
                }
                updateStatus()
                true
            }

        findPreference<Preference>("demo")?.setOnPreferenceClickListener {
            startActivity(Intent(requireContext(), DemoActivity::class.java))
            true
        }
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun updateStatus() {
        val ctx = context ?: return
        val anim = if (AnimationController.hasSecurePermission(ctx)) "aktif" else "butuh izin ADB"
        val hz = if (AnimationController.canWriteSystem(ctx)) "aktif" else "butuh izin Ubah setelan sistem"
        findPreference<Preference>("status")?.summary =
            "Skala animasi sistem: $anim\nRefresh rate: $hz"
    }
}
