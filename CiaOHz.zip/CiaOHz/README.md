# CiaO Hz

Aplikasi Android (Kotlin) dengan UI Setelan native:
- **Max Animation Smoother** (toggle)
- **Motion Blur** (toggle)

## Cara build
1. Buka folder `CiaOHz` di **Android Studio** (Koala atau lebih baru). Gradle wrapper akan dibuat otomatis, tunggu sync selesai.
2. Colok HP (USB debugging aktif) lalu **Run**, atau **Build > Build APK(s)**.

## Cara mengaktifkan
Sistem Android melindungi pengaturan animasi, jadi ada dua izin sekali pasang:

3. **Izin skala animasi sistem** (lewat komputer, HP terhubung USB debugging):
   ```
   adb shell pm grant com.ciao.hz android.permission.WRITE_SECURE_SETTINGS
   ```
4. **Izin refresh rate**: saat toggle Max Animation Smoother dinyalakan pertama kali, aplikasi membuka layar "Ubah setelan sistem"; aktifkan untuk CiaO Hz.

## Batasan yang perlu diketahui
- **240 Hz tidak bisa dipaksakan oleh aplikasi.** Aplikasi hanya meminta refresh rate tertinggi; angka akhirnya ditentukan panel layar HP. Jika layar Anda maksimal 120 Hz, hasilnya 120 Hz. Sebagian merek tidak membaca key refresh rate ini.
- **Efek di seluruh HP** berasal dari skala animasi sistem (diset 0.5x: buka/tutup aplikasi lebih cepat dan halus). Ini sama dengan opsi di Opsi Pengembang.
- **Motion Blur** berlaku pada geser halaman **di dalam aplikasi ini** (halaman "Coba Motion Blur", butuh Android 12+). Android tidak mengizinkan aplikasi biasa menambah blur ke layar utama atau aplikasi lain.
